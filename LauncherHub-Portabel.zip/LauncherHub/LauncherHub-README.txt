LAUNCHER HUB
============

Start: LauncherHub.cmd doppelklicken. Windows 10 oder 11 wird benoetigt.
Die Dateien LauncherHub.cmd, LauncherHub.ps1 und LauncherHubUpdates.ps1
muessen zusammen im selben Ordner bleiben.

Beim ersten Start sucht der Hub nach bekannten Launchern im Startmenue,
auf dem Desktop und in den Installations-Eintraegen von Windows. Die Auswahl wird fuer jeden Windows-Nutzer
separat unter %APPDATA%\LauncherHub\config.json gespeichert.

Auto-Erkennung: bekannte Launcher erneut suchen und hinzufuegen. Nicht
registrierte portable Programme koennen ueber Hinzufuegen gewaehlt werden.
Hinzufuegen: eine EXE-, LNK- oder URL-Datei selbst auswaehlen.
X auf einer Kachel: nur aus dem Hub entfernen. Programme bleiben installiert.
Autostart-Haekchen: legt fuer diesen Launcher eine Verknuepfung im persoenlichen
Windows-Autostart-Ordner an oder entfernt sie. Eigene Autostart-Einstellungen
des Launchers werden dadurch nicht geaendert; falls dort bereits Autostart
aktiv ist, kann das Programm beim Anmelden doppelt gestartet werden.

Gruener Punkt = ein passender Prozess laeuft. Grau = nicht erkannt.
Versionshinweise stammen von WinGet, falls es installiert ist. Ein Hinweis
bedeutet nicht automatisch, dass der Launcher selbst ein Update verlangt.
Wenn die Programmdatei bereits die angebotene Version hat, wird ein alter
Registry-Eintrag als solcher erkannt. Der Hub installiert keine Updates.

Zum Weitergeben: den gesamten ZIP-Inhalt entpacken und LauncherHub.cmd
starten. Jeder PC erkennt seine eigenen installierten Launcher und fuehrt
eine eigene Auswahl. Es werden keine Spiele oder Launcher mitgeliefert.
